﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tree : MonoBehaviour
{
    public bool drawGizmos = true;
    public Texture2D tex;
    public Light light;
    public Shader SSVolShadow;
    private Material drawMaterial;
    private RenderTexture rt_mask;
    public Transform testPoint;

    public bool clipMode;
    private List<Vector2Int> shadows;
    public bool debugCellMode = false;

    int timeCount = 0;

    private void Start()
    {
        InitShadowData();
    }

    private void InitShadowData()
    {
        shadows = FindPosInShadow(-light.transform.forward);
        Node root = new Node();
        root.x = 0;
        root.z = 0;
        root.size = 1024;

        foreach(var d in shadows)
        {
            root.Insert(d.x, d.y);
        }

        root.ClipSameNode();

        root.PrintCount();

        var nodes = root.GetAllNodes();
        Debug.Log(nodes.Count);
        int width = Mathf.CeilToInt(Mathf.Sqrt(nodes.Count));
        tex = new Texture2D(width, width, TextureFormat.RGBAFloat, false);
        tex.filterMode = FilterMode.Point;
        tex.wrapMode = TextureWrapMode.Clamp;

        drawMaterial = new Material(SSVolShadow);

        rt_mask = RenderTexture.GetTemporary(Screen.width, Screen.height, 0, RenderTextureFormat.R8);
        Shader.SetGlobalTexture("_TestQTreeMaskTex", rt_mask);

        var colors = tex.GetPixels();
        for(int i = 0; i < nodes.Count; ++i)
        {
            nodes[i].index = i;
        }
        for(int i = 0; i < nodes.Count; ++i)
        {
            colors[i].r = nodes[i].x;
            colors[i].g = nodes[i].z;
            colors[i].b = nodes[i].children != null ? nodes[i].children[0].index : -1;
            colors[i].a = nodes[i].flag;
        }
        tex.SetPixels(colors);
        tex.Apply();
        Shader.SetGlobalTexture("_TestQTreeTex", tex);
        Shader.SetGlobalInt("_TestQTreeWidth", width);
    }

    private void OnPreRender()
    {
        GetComponent<Camera>().depthTextureMode = DepthTextureMode.Depth;
    }

    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        Camera cam = GetComponent<Camera>();
        float aspect = cam.aspect;
        float near = cam.nearClipPlane;
        float far = cam.farClipPlane;

        float halfFovTan = Mathf.Tan(cam.fieldOfView * 0.5f * Mathf.Deg2Rad);
        Vector3 up = cam.transform.up;
        Vector3 right = cam.transform.right;
        Vector3 forward = cam.transform.forward;

        Vector3 forwardVector = forward * far;
        Vector3 upVector = up * far * halfFovTan;
        Vector3 rightVector = right * far * halfFovTan * aspect;

        Vector3 topLeft = forwardVector - rightVector + upVector;
        Vector3 topRight = forwardVector + rightVector + upVector;
        Vector3 bottomLeft = forwardVector - rightVector - upVector;
        Vector3 bottomRight = forwardVector + rightVector - upVector;

        Matrix4x4 viewPortRay = Matrix4x4.identity;
        viewPortRay.SetRow(0, topLeft);
        viewPortRay.SetRow(1, topRight);
        viewPortRay.SetRow(2, bottomLeft);
        viewPortRay.SetRow(3, bottomRight);

        Shader.SetGlobalMatrix("_FrustumCornerRay", viewPortRay);
        Graphics.Blit(source, rt_mask, drawMaterial, 0);
        Graphics.Blit(source, destination, drawMaterial, 1);
    }

    private void OnDrawGizmos()
    {
        if (!drawGizmos) return;
        //timeCount++;
        //if(timeCount > 24)
        //{
        //    shadows = FindPosInShadow(-light.transform.forward);
        //    timeCount = 0;
        //}
        Node root = new Node();
        root.x = 0;
        root.z = 0;
        root.size = 1024;
        foreach(var d in shadows) root.Insert(d.x, d.y);
        if (clipMode) root.ClipSameNode();
        root.PrintCount();
        float drawScale = 0.1f;
        root.Draw(drawScale);
    }

    public static List<Vector2Int> FindPosInShadow(Vector3 lightDir)
    {
        List<Vector2Int> list = new List<Vector2Int>();
        // 1024 => 102.4m & 1024 => 1024grid
        // 1grid => 0.1m
        for(int x = 0; x < 1024; ++x)
        {
            for(int z = 0; z < 1024; ++z)
            {
                Vector3 pos = new Vector3(x * 0.1f, 0.001f, z * 0.1f);
                if((Physics.Raycast(pos, lightDir, 100) ? 1 : 0)
                + (Physics.Raycast(pos + new Vector3(-1, 0, 0) * 0.05f, lightDir, 100) ? 1 : 0)
                + (Physics.Raycast(pos + new Vector3(0, -1, 0) * 0.05f, lightDir, 100) ? 1 : 0)
                + (Physics.Raycast(pos + new Vector3(0, 0, -1) * 0.05f, lightDir, 100) ? 1 : 0)
                + (Physics.Raycast(pos + new Vector3(1, 0, 0) * 0.05f, lightDir, 100) ? 1 : 0)
                + (Physics.Raycast(pos + new Vector3(0, 1, 0) * 0.05f, lightDir, 100) ? 1 : 0)
                + (Physics.Raycast(pos + new Vector3(0, 0, 1) * 0.05f, lightDir, 100) ? 1 : 0)
                    > 2)
                {
                    list.Add(new Vector2Int(x, z));
                }
            }
        }
        return list;
    }

    private void OnDestroy()
    {
        RenderTexture.ReleaseTemporary(rt_mask);
    }
}
